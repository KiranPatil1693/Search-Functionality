import React from 'react'
const DisplayCloths = () => {
	return (
		<div>
        	<h1>Displaying Cloths</h1>
        	<p>It will show data from Cloths categories only</p>
		</div>
	)
}
export default DisplayCloths
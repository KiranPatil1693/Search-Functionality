import React from 'react'
const DisplayDiamonds = () => {
	return (
		<div>
        	<h1>Displaying Diamonds</h1>
        	<p>It will show data from Diamonds categories only</p>
		</div>
	)
}
export default DisplayDiamonds
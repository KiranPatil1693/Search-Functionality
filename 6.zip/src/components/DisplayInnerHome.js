import React from 'react'
const DisplayHome = () => {
	return (
		<div>
        	<h1>This is Inner Home</h1>
        	<p>This will get open only when user has logged in</p>
		</div>
	)
}
export default DisplayHome
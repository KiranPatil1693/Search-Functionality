import React from 'react'
import IntroImage from'../shop.jpg';
const HomeIntroduction = ({ onClick }) => {
	return (
		<div className='home-introduction-container'>
		  <div className='home-introduction' >
		    <div className='home-introduction-div'>
		    	<h1>One Stop Buying Place</h1>
		    	<span className='home-introduction-span' onClick={ onClick }>Get Started</span>
		    </div>
		    <img src={IntroImage} alt='#' width='100%' height='auto' className='home-introduction-img'/>
		  </div>
		</div>
	)
}
export default HomeIntroduction 
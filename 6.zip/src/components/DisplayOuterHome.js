import React from 'react'
import HomeIntroductionContainer from '../containers/HomeIntroductionContainer'
import HomeTabIntroContainer from '../containers/HomeTabIntroContainer'
const DisplayHome = () => {
	return (
		<div>
        	<HomeIntroductionContainer />
        	<HomeTabIntroContainer />
		</div>
	)
}
export default DisplayHome
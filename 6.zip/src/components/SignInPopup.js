import React from 'react'
import PropTypes from 'prop-types'
const SignInPopup = ({isSignInPopupOn,onClick,on2click}) => {
      	return (isSignInPopupOn === true && 
      	<div>
          <div className='Popup-total-window'>
            <div className='Popup-main-window'>
              <div className='PopupGrid'>
                <div>Sign In Popup</div>
                <div onClick={onClick} className='Popup-close-window' >X</div>  
              </div>
              <button onClick={on2click}>Submit</button>
            </div>
          </div>
      	</div>)
}
SignInPopup.propTypes = {
  isSignInPopupOn: PropTypes.bool.isRequired,
  onClick: PropTypes.func.isRequired
}
export default SignInPopup
import React from 'react'
const DisplayMobiles = () => {
	return (
		<div>
        	<h1>Displaying Mobiles</h1>
        	<p>It will show data from Mobiles categories only</p>
		</div>
	)
}
export default DisplayMobiles
import React from 'react'
const HomeLogo = ({ isSignedIn, on1Click, on2Click }) => {
	const homeLogoToggle = isSignedIn?<div onClick={on1Click} className='home-logo'>Logo</div>:<div onClick={on2Click} className='home-logo'>Logo</div>;
	return (
    	homeLogoToggle 
	)
}
export default HomeLogo
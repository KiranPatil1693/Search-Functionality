import React from 'react'
const DisplayCars = () => {
	return (
		<div>
        	<h1>Displaying Cars</h1>
        	<p>It will show data from Cars categories only</p>
		</div>
	)
}
export default DisplayCars
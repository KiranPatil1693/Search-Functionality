import React from 'react'
const SignIn = ({ isSignedIn, onClick}) => {
	const signInDisplay = isSignedIn?(<span>Profile</span>):(<span className="sign-in" onClick={onClick}>Sign In</span>);
	return (
		<div>
	  		{signInDisplay}
	  	</div>
    )
}
export default SignIn
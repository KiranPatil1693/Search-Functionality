import React from 'react'
const DiamondsTab = ({onClick}) => (
		<div onClick={onClick} className='tab-head' >
			Diamonds
		</div>
		)
export default DiamondsTab
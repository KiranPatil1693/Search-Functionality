import React from 'react'
import IntroPetsImage from'../pets.jpg';
import IntroCarsImage from'../cars.jpg';
import IntroClothsImage from'../cloths.jpg';
import IntroDiamondsImage from'../diamonds.jpg';
import IntroMobilesImage from'../mobiles.jpg';
const HomeTabIntro = ({ on1click, on2click, on3click, on4click, on5click, on6click }) => {
	return (
		<div>
			<div className="home-tab-intro-top">
				<div>
					<div className='home-tab-introduction'><img alt="#" src={IntroPetsImage} width='100%' height='auto' className='home-introduction-img'/></div>
					<div style={{textAlign:'center'}}>1500 Pets Available</div>
					<div className='home-tab-intro' onClick={on1click}>Buy Pets</div>
				</div>
				<div>
					<div className='home-tab-introduction'><img alt="#" src={IntroCarsImage} width='100%' height='auto' className='home-introduction-img'/></div>
					<div style={{textAlign:'center'}}>500 Cars Available</div>
					<div className='home-tab-intro' onClick={on2click}>Buy Cars</div>
				</div>
				<div>
					<div className='home-tab-introduction'><img alt="#" src={IntroClothsImage} width='100%' height='auto' className='home-introduction-img'/></div>
					<div style={{textAlign:'center'}}>5500 Cloths Available</div>
					<div className='home-tab-intro' onClick={on3click}>Buy Cloths</div>
				</div>
			</div>
			<div className="home-tab-intro-bottom">
				<div>
					<div className='home-tab-introduction'><img alt="#" src={IntroDiamondsImage} width='100%' height='auto' className='home-introduction-img'/></div>
					<div style={{textAlign:'center'}}>200 Diamonds Available</div>
					<div className='home-tab-intro' onClick={on4click}>Buy Diamonds</div>
				</div>
				<div>
					<div className='home-tab-introduction'><img alt="#" src={IntroMobilesImage} width='100%' height='auto' className='home-introduction-img'/></div>
					<div style={{textAlign:'center'}}>2500 Mobiles Available</div>
					<div className='home-tab-intro' onClick={on5click}>Buy Mobiles</div>
				</div>
			</div>
			<div className='home-tab-intro-getStarted-container'>
			    <span></span>
			    <span></span>
				<span className='home-tab-intro-getStarted' onClick={ on6click }>Get Started</span>
				<span></span>
				<span></span>	
			</div>
		</div>
	)
}
export default HomeTabIntro
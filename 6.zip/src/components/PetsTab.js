import React from 'react'
const PetsTab = ({onClick}) => (
		<div onClick={onClick} className='tab-head'>
			Pets
		</div>
		)
export default PetsTab


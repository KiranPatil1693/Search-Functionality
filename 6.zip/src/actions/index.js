export const ShowSearchDropdown = () => ({
    type: 'SHOW_SEARCH_DROPDOWN'
}) 
export const searchOn1Click = () => ({
    type: 'SEARCH_ON1_CLICK'
})
export const searchOn2Click = () => ({
    type: 'SEARCH_ON2_CLICK'
})
export const searchOn3Click = () => ({
    type: 'SEARCH_ON3_CLICK'
})
export const searchOn4Click = () => ({
    type: 'SEARCH_ON4_CLICK'
})
export const searchOn5Click = () => ({
    type: 'SEARCH_ON5_CLICK'
})
export const searchOn6Click = () => ({
    type: 'SEARCH_ON6_CLICK'
})
export const SearchSelectOnChange = SearchSelectValue => ({
    type: 'SEARCH_SELECT_ON_CHANGE',
    SearchSelectValue
})
export const SearchSuggestionClick = SearchSuggestionValue => ({
    type: 'SEARCH_SUGGESTION_CLICK',
    SearchSuggestionValue
})
export const SearchGetSuggestions = GetSuggestionsValue => ({
    type: 'SEARCH_GET_SUGGESTIONS',
    GetSuggestionsValue
})
export const SearchSubmit = SearchSubmitValue => ({
    type: 'SEARCH_SUBMIT',
    SearchSubmitValue
})
export const headerSignInClick = () => ({
    type: 'HEADER_SIGN_IN_CLICK'
})
export const homeSignInClick = () => ({
    type: 'HOME_SIGN_IN_CLICK'
})
export const submitClick = () => ({
    type: 'SUBMIT_CLICK'  
})
export const exitClick = () => ({
    type: 'EXIT_CLICK'  
})
export const innerHomeLogoClick = () => ({
    type: 'INNER_HOME_LOGO_CLICK'
})
export const outerHomeLogoClick = () => ({
    type: 'OUTER_HOME_LOGO_CLICK'
})
export const petsTabClick = () => ({
    type: 'PETS_TAB_CLICK'
})
export const carsTabClick = () => ({
    type: 'CARS_TAB_CLICK'
})
export const mobilesTabClick = () => ({
    type: 'MOBILES_TAB_CLICK'
})
export const clothsTabClick = () => ({
    type: 'CLOTHS_TAB_CLICK'
})
export const diamondsTabClick = () => ({
    type: 'DIAMONDS_TAB_CLICK'
})
export const homePetsTabClick = () => ({
    type: 'HOME_PETS_TAB_CLICK'
})
export const homeCarsTabClick = () => ({
    type: 'HOME_CARS_TAB_CLICK'
})
export const homeClothsTabClick = () => ({
    type: 'HOME_CLOTHS_TAB_CLICK'
})
export const homeDiamondsTabClick = () => ({
    type: 'HOME_DIAMONDS_TAB_CLICK'
})
export const homeMobilesTabClick = () => ({
    type: 'HOME_MOBILES_TAB_CLICK'
})

import { combineReducers } from 'redux'
import Search from '../reducers/Search'
export default combineReducers({
  Search
})
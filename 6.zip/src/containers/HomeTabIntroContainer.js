import { connect } from 'react-redux'
import HomeTabsIntro from '../components/HomeTabsIntro'
import { homePetsTabClick, homeCarsTabClick, homeClothsTabClick, homeDiamondsTabClick, homeMobilesTabClick, homeSignInClick} from '../actions/index'
const mapDispatchToProps = dispatch => ({
	on1click: () => dispatch(homePetsTabClick()),
	on2click: () => dispatch(homeCarsTabClick()),
	on3click: () => dispatch(homeClothsTabClick()),
	on4click: () => dispatch(homeDiamondsTabClick()),
	on5click: () => dispatch(homeMobilesTabClick()),
	on6click: () => dispatch(homeSignInClick()),
})
export default connect( null, mapDispatchToProps )(HomeTabsIntro)
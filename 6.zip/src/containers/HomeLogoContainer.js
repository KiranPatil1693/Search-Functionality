import { connect } from 'react-redux'
import HomeLogo from '../components/HomeLogo'
import { innerHomeLogoClick, outerHomeLogoClick } from '../actions/index'
const mapStateToProps = state => ({
	isSignedIn: state.Search.isSignedIn
})
const mapDispatchToProps = dispatch => ({
	on1Click: () => dispatch(innerHomeLogoClick()),
	on2Click: () => dispatch(outerHomeLogoClick())
})
export default connect( mapStateToProps, mapDispatchToProps)( HomeLogo)
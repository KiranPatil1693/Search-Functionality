import { connect } from 'react-redux'
import Display from '../components/Display'
const mapStateToProps = state => ({
	whichTabIsOn: state.Search.whichTabIsOn
})
export default connect( mapStateToProps )(Display)
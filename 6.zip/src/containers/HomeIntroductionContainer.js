import { connect } from 'react-redux'
import HomeIntroduction from '../components/HomeIntroduction'
import { homeSignInClick } from '../actions/index'
const mapDisptchToProps = dispatch => ({
	onClick: () => dispatch(homeSignInClick())
})
export default connect( null, mapDisptchToProps)(HomeIntroduction)
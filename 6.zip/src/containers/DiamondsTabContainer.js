import {connect} from 'react-redux'
import DiamondsTab from '../components/DiamondsTab'
import {diamondsTabClick} from '../actions/index'
const mapDispatchToProps = dispatch => ({
	onClick: () => dispatch(diamondsTabClick())
})
export default connect(null, mapDispatchToProps)(DiamondsTab)
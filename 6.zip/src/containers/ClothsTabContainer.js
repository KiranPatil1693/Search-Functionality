import {connect} from 'react-redux'
import ClothsTab from '../components/ClothsTab'
import {clothsTabClick} from '../actions/index'
const mapDispatchToProps = dispatch => ({
	onClick: () => dispatch(clothsTabClick())
})
export default connect(null, mapDispatchToProps)(ClothsTab)
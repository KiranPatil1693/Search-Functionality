import { connect } from 'react-redux'
import PetsTab from '../components/PetsTab'
import {petsTabClick} from '../actions/index'
const mapDispatchToProps = dispatch => ({
	onClick: () => dispatch(petsTabClick())
})
export default connect(null, mapDispatchToProps)(PetsTab)
import {connect} from 'react-redux'
import MobilesTab from '../components/MobilesTab'
import {mobilesTabClick} from '../actions/index'
const mapDispatchToProps = dispatch => ({
	onClick: () => dispatch(mobilesTabClick())
})
export default connect(null, mapDispatchToProps)( MobilesTab )
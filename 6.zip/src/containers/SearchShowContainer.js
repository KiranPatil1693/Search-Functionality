import { connect } from 'react-redux'
import SearchShowSelect from '../components/SearchShowSelect'
import { ShowSearchDropdown } from '../actions/index'
const mapStateToProps = state => ({
	whichSearchIsOn: state.Search.whichSearchIsOn
})
const mapDispatchToProps = dispatch => ({
	onClick: () => dispatch(ShowSearchDropdown())
})
export default connect( mapStateToProps, mapDispatchToProps )( SearchShowSelect )
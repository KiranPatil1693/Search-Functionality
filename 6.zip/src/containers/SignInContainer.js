import {connect} from 'react-redux'
import SignIn from '../components/SignIn'
import {headerSignInClick} from '../actions/index.js'
const mapStateToProps = (state) => ({
	isSignedIn: state.Search.isSignedIn
})
const mapDispatchToProps = (dispatch) => ({
	onClick: () => dispatch(headerSignInClick())
})
export default connect(mapStateToProps,mapDispatchToProps)(SignIn) 
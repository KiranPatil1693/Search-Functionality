import React from 'react'
const HomeLogo = ({onClick}) => {
	return (
    <div onClick={onClick} className='home-logo'>Logo</div>
	)
}
export default HomeLogo
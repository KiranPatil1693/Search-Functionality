import React from 'react'
const ClothsTab = ({onClick}) => (
		<div onClick={onClick} className='tab-head'>
			Cloths
		</div>
		)
export default ClothsTab
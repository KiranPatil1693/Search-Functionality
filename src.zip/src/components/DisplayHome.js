import React from 'react'
import HomeIntroduction from '../components/HomeIntroduction'
const DisplayHome = () => {
	return (
		<div>
        	<HomeIntroduction />
		</div>
	)
}
export default DisplayHome
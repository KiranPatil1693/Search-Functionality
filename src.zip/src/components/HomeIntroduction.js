import React from 'react'
import IntroImage from'../cars.jpg';

const HomeIntroduction = () => {
	return (
		<div className='home-introduction-container'>
		  <div className='home-introduction' >
		    <div className='home-introduction-div'>
		    	<h1>One Stop Buying Place</h1>
		    	<span className='home-introduction-span'>Get Started</span>
		    </div>
		    <img src={IntroImage} width='100%' height='auto' className='all-introduction-img'/>
		  </div>
		</div>
	)
}
export default HomeIntroduction 
import React from 'react'
const DisplayPets = () => {
	return (
		<div>
        	<h1>Displaying Pets</h1>
        	<p>It will show data from Pets categories only</p>
		</div>
	)
}
export default DisplayPets
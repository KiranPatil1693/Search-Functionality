import React from 'react'
import SearchSelectContainer from '../containers/SearchSelectContainer'
import SearchShowDropdownContainer from '../containers/SearchShowDropdownContainer'
import SearchShowContainer from '../containers/SearchShowContainer'
import SearchTypeContainer from '../containers/SearchTypeContainer'
import SignInContainer from '../containers/SignInContainer'
import SignInPopupContainer from '../containers/SignInPopupContainer'
import AllTabContainer from '../containers/AllTabContainer'
import CarsTabContainer from '../containers/CarsTabContainer'
import DiamondsTabContainer from '../containers/DiamondsTabContainer'
import ClothsTabContainer  from '../containers/ClothsTabContainer'
import MobilesTabContainer from '../containers/MobilesTabContainer'
import DisplayContainer from '../containers/DisplayContainer'
import HomeLogoContainer from '../containers/HomeLogoContainer'
const App = () => {
	return (
      <div>
        <div>
          <div className="SearchGrid">
            <span><HomeLogoContainer /></span>
            <span><span className="search-select"><SearchShowContainer /><SearchShowDropdownContainer /></span></span>
            <span><SearchTypeContainer /></span>
            <span><SignInContainer /></span>
          </div>
          <div>
            <SignInPopupContainer />
          </div>
        </div>
        <div className="tab-container">
          <AllTabContainer />
          <CarsTabContainer />
          <ClothsTabContainer />
          <DiamondsTabContainer />
          <MobilesTabContainer />
        </div>
        <div>
          <DisplayContainer />
        </div>
      </div>
	)
} 
export default App
import React from 'react'
import PropTypes from 'prop-types'
const SearchType = ({SearchPlaceholder, GetSuggestionsList}) => {
	return (
      <span>
        <form action='#'>
          <input type='text' placeholder={SearchPlaceholder} onChange={GetSuggestionsList} style={{width:'100%'}} />
        </form>
      </span>
	)
}
SearchType.propTypes = {
	SearchPlaceholder: PropTypes.string.isRequired
}
export default SearchType
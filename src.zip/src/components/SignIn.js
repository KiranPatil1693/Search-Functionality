import React from 'react'
import PropTypes from 'prop-types'
const SignIn = ({onClick}) => {
	return (
		<span className="sign-in" onClick={onClick}>Sign In</span>
    )
}
SignIn.propTypes = {
	onClick: PropTypes.func.isRequired
}
export default SignIn
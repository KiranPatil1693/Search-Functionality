import React from 'react'
import DisplayHome from '../components/DisplayHome'
import DisplayPets from '../components/DisplayPets'
import DisplayCars from '../components/DisplayCars'
import DisplayMobiles from '../components/DisplayMobiles'
import DisplayCloths from '../components/DisplayCloths'
import DisplayDiamonds from '../components/DisplayDiamonds'
const Display = ({whichTabIsOn}) => {
	switch(whichTabIsOn) {
		case 'Home': 
			return (<DisplayHome />)
		case 'PETS':
			return (<DisplayPets />)
		case 'CARS':
			return (<DisplayCars />)
		case 'MOBILES':
			return (<DisplayMobiles />)
		case 'CLOTHS':
			return (<DisplayCloths />)
		case 'DIAMONDS':
			return (<DisplayDiamonds />)
		default:
			return (<DisplayHome />)
	}
}
export default Display
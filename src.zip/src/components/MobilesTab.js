import React from 'react'
const MobilesTab = ({onClick}) => (
		<div onClick={onClick} className='tab-head'>
			Mobiles
		</div>
		)
export default MobilesTab

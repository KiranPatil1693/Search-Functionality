import React from 'react'
const SearchSelectDropdown = ({showSearchDropdown,on1Click,on2Click,on3Click,on4Click,on5Click,on6Click}) => {
	return (
        <div>
        	{
        	showSearchDropdown && (
        	  <div className="search-select-dropdown">
        	  	<div onClick={on1Click} className='search-select-dropdown-option'>All</div>
		      	<div onClick={on2Click} className='search-select-dropdown-option'>Cars</div>
		      	<div onClick={on3Click} className='search-select-dropdown-option'>Mobiles</div>
		      	<div onClick={on4Click} className='search-select-dropdown-option'>Cloths</div>
		      	<div onClick={on5Click} className='search-select-dropdown-option'>Diamonds</div>
		      	<div onClick={on6Click} className='search-select-dropdown-option'>Pets</div>
		      </div>
		      )	
        	}
        </div>
		)		  
} 
export default SearchSelectDropdown
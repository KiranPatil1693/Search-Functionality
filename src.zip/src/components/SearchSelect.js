import React from 'react'
const SearchSelect = ({onSelectChange}) => (
          <span>
            <select onChange={onSelectChange} style={{width:'100%'}}>
              <option  value='All'>All</option>
              <option  value='Cars'>Cars</option>
              <option  value='Mobiles'>Mobiles</option>
              <option  value='Cloths'>Cloths</option>
              <option  value='Diamonds'>Diamonds</option>
            </select>
          </span>
		)
export default SearchSelect
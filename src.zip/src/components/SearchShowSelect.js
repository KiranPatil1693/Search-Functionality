import React from 'react'
const SearchShowSelect = ({whichSearchIsOn,onClick}) => {
	return (
		<div onClick={onClick} className='search-show-select'>
			{whichSearchIsOn}
		</div>
		)
} 
export default SearchShowSelect
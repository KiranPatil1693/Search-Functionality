import React from 'react'
const CarsTab = ({onClick}) => (
		<div onClick={onClick} className='tab-head'>
			Cars
		</div>
		)
export default CarsTab
import React from 'react'
import {connect} from 'react-redux'
import SignIn from '../components/SignIn'
import {signInClick} from '../actions/index.js'
const mapDispatchToProps = (dispatch) => ({
	onClick: () => dispatch(signInClick())
})
export default connect(null,mapDispatchToProps)(SignIn) 
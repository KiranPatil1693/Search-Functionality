import React from 'react'
import { connect } from 'react-redux'
import HomeLogo from '../components/HomeLogo'
import { homeLogoClick } from '../actions/index'
const mapDispatchToProps = dispatch => ({
	onClick: () => dispatch(homeLogoClick())
})
export default connect( null, mapDispatchToProps)( HomeLogo)
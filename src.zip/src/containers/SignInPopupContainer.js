import React from 'react'
import {connect} from 'react-redux'
import SignInPopup from '../components/SignInPopup'
import {exitClick} from '../actions/index'
const mapStateToProps = state => ({
	isSignInPopupOn: state.Search.isSignInPopupOn
})
const mapDispatchToProps = dispatch => ({
	onClick: () => dispatch(exitClick())
})
export default connect(mapStateToProps,mapDispatchToProps)(SignInPopup)
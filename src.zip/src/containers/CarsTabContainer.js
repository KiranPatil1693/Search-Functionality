import React from 'react'
import {connect} from 'react-redux'
import CarsTab from '../components/CarsTab'
import {carsTabClick} from '../actions/index'
const mapDispatchToProps = dispatch => ({
	onClick: () => dispatch(carsTabClick())
})
export default connect(null, mapDispatchToProps)(CarsTab)
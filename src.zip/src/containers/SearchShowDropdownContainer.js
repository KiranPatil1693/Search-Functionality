import React from 'react'
import { connect } from 'react-redux'
import SearchSelectDropdown from '../components/SearchSelectDropdown'
import {searchOn1Click} from '../actions/index'
import {searchOn2Click} from '../actions/index'
import {searchOn3Click} from '../actions/index'
import {searchOn4Click} from '../actions/index'
import {searchOn5Click} from '../actions/index'
import {searchOn6Click} from '../actions/index'
const mapStateToProps = state => ({
	showSearchDropdown: state.Search.showSearchDropdown
})
const mapDispatchToProps = dispatch => ({
	on1Click: () => dispatch(searchOn1Click()),
	on2Click: () => dispatch(searchOn2Click()),
	on3Click: () => dispatch(searchOn3Click()),
	on4Click: () => dispatch(searchOn4Click()),
	on5Click: () => dispatch(searchOn5Click()),
	on6Click: () => dispatch(searchOn6Click())
})
export default connect( mapStateToProps, mapDispatchToProps )(SearchSelectDropdown) 
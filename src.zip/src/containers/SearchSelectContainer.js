import React from 'react'
import { connect } from 'react-redux'
import SearchSelect from '../components/SearchSelect'
import { SearchSelectOnChange } from '../actions/index.js' 
const mapDispatchToProps = dispatch => ({
	onSelectChange: (event) => dispatch(SearchSelectOnChange(event.target.value))
})
export default connect(null, mapDispatchToProps)(SearchSelect)

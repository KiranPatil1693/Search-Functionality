import React from 'react'
import {connect} from 'react-redux'
import SearchType from '../components/SearchType'
import { SearchGetSuggestions } from '../actions/index'
const mapStateToProps = state => ({
  SearchPlaceholder: state.Search.SearchPlaceholder
})
const mapDispatchToProps = dispatch => ({
  GetSuggestionsList: () => dispatch(SearchGetSuggestions())
})
export default connect(mapStateToProps, mapDispatchToProps)(SearchType)

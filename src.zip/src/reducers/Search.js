const InitialState = ({
  SearchSelectValue: 'All',
  SearchPlaceholder: 'Search in All',
  isSignInPopupOn: false,
  whichTabIsOn: 'Home',
  showSearchDropdown: false,
  whichSearchIsOn: 'All'
})
const Search = (state=InitialState,action) => {
    switch (action.type) {
        case 'SEARCH_SELECT_ON_CHANGE':
          return {
          	...state,
            SearchSelectValue: action.SearchSelectValue,
            SearchPlaceholder: `Search in ${action.SearchSelectValue}`,
            showSearchDropdown: false  
          }
        case 'SIGN_IN_CLICK':
          return {
            ...state,
            isSignInPopupOn: true,
            showSearchDropdown: false,             
          }
        case 'EXIT_CLICK':
          return {
            ...state,
            isSignInPopupOn: false             
          }
        case 'HOME_LOGO_CLICK':
          return {
            ...state,
            whichTabIsOn: 'Home',
            whichSearchIsOn: 'All',
            showSearchDropdown: false,
            SearchPlaceholder: 'Search in All'
          }
        case 'PETS_TAB_CLICK':
          return {
            ...state,
            whichTabIsOn: 'PETS',
            whichSearchIsOn: 'Pets',
            showSearchDropdown: false,
            SearchPlaceholder: 'Search in Pets'
          }
        case 'CARS_TAB_CLICK':
          return {
            ...state,
            whichTabIsOn: 'CARS',
            whichSearchIsOn: 'Cars',
            showSearchDropdown: false,
            SearchPlaceholder: 'Search in Cars'
          }
        case 'MOBILES_TAB_CLICK':
          return {
            ...state,
            whichTabIsOn: 'MOBILES',
            whichSearchIsOn: 'Mobiles',
            showSearchDropdown: false,
            SearchPlaceholder: 'Search in Mobiles'
          }
        case 'CLOTHS_TAB_CLICK':
          return {
            ...state,
            whichTabIsOn: 'CLOTHS',
            whichSearchIsOn: 'Cloths',
            showSearchDropdown: false,
            SearchPlaceholder: 'Search in Cloths'
          }
        case 'DIAMONDS_TAB_CLICK':
          return {
            ...state,
            whichTabIsOn: 'DIAMONDS',
            whichSearchIsOn: 'Diamonds',
            showSearchDropdown: false,
            SearchPlaceholder: 'Search in Diamonds'
          }
        case 'SHOW_SEARCH_DROPDOWN':
          return {
            ...state,
            showSearchDropdown: !state.showSearchDropdown
          }
        case 'SEARCH_ON1_CLICK':
          return {
            ...state,
            whichSearchIsOn: 'All',
            showSearchDropdown: false,
            SearchPlaceholder: 'Search in All'
          }
        case 'SEARCH_ON2_CLICK':
          return {
            ...state,
            whichSearchIsOn: 'Cars',
            showSearchDropdown: false,
            SearchPlaceholder: 'Search in Cars'
          }
        case 'SEARCH_ON3_CLICK':
          return {
            ...state,
            whichSearchIsOn: 'Mobiles',
            showSearchDropdown: false,
            SearchPlaceholder: 'Search in Mobiles'
          }
        case 'SEARCH_ON4_CLICK':
          return {
            ...state,
            whichSearchIsOn: 'Cloths',
            showSearchDropdown: false,
            SearchPlaceholder: 'Search in Cloths'
          }
        case 'SEARCH_ON5_CLICK':
          return {
            ...state,
            whichSearchIsOn: 'Diamonds',
            showSearchDropdown: false,
            SearchPlaceholder: 'Search in Diamonds'
          }
        case 'SEARCH_ON6_CLICK':
          return {
            ...state,
            whichSearchIsOn: 'Pets',
            showSearchDropdown: false,
            SearchPlaceholder: 'Search in Pets'
          }
        default:
          return state
      }
    }
export default Search
export const ShowSearchDropdown = () => ({
    type: 'SHOW_SEARCH_DROPDOWN'
}) 
export const searchOn1Click = () => ({
    type: 'SEARCH_ON1_CLICK'
})
export const searchOn2Click = () => ({
    type: 'SEARCH_ON2_CLICK'
})
export const searchOn3Click = () => ({
    type: 'SEARCH_ON3_CLICK'
})
export const searchOn4Click = () => ({
    type: 'SEARCH_ON4_CLICK'
})
export const searchOn5Click = () => ({
    type: 'SEARCH_ON5_CLICK'
})
export const searchOn6Click = () => ({
    type: 'SEARCH_ON6_CLICK'
})
export const SearchSelectOnChange = SearchSelectValue => ({
    type: 'SEARCH_SELECT_ON_CHANGE',
    SearchSelectValue
})
export const SearchSuggestionClick = SearchSuggestionValue => ({
    type: 'SEARCH_SUGGESTION_CLICK',
    SearchSuggestionValue
})
export const SearchGetSuggestions = GetSuggestionsValue => ({
    type: 'SEARCH_GET_SUGGESTIONS',
    GetSuggestionsValue
})
export const SearchSubmit = SearchSubmitValue => ({
    type: 'SEARCH_SUBMIT',
    SearchSubmitValue
})
export const signInClick = () => ({
    type: 'SIGN_IN_CLICK'
})
export const exitClick = () => ({
    type: 'EXIT_CLICK'  
})
export const homeLogoClick = () => ({
    type: 'HOME_LOGO_CLICK'
})
export const petsTabClick = () => ({
    type: 'PETS_TAB_CLICK'
})
export const carsTabClick = () => ({
    type: 'CARS_TAB_CLICK'
})
export const mobilesTabClick = () => ({
    type: 'MOBILES_TAB_CLICK'
})
export const clothsTabClick = () => ({
    type: 'CLOTHS_TAB_CLICK'
})
export const diamondsTabClick = () => ({
    type: 'DIAMONDS_TAB_CLICK'
})
